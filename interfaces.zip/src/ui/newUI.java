package ui;

import javax.swing.*;

public class newUI {
    private JPanel inicio;
    private JButton INICIARbt;
    private JButton REGISTRARbt;

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
