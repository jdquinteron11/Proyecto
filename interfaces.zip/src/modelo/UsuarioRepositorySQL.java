package modelo;
                    // Lu aca va la rama SQL en la cual estas trabajando y viendo videos de como hacer el repositorio SQL
public class UsuarioRepositorySQL {
}
