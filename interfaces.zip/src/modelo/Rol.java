package modelo;

public enum Rol {
    Rector,
    Abogado,
    Administrador
}
